Thank you for downloading SNESHunter!  Here are some quick instructions to help you get started:

Prerequisites:
1. You will need to have login information for an Email account from which to send alerts.  Make sure you have the correct SMTP server, port number, username and password
2. Run SNESHunter on a computer that can remain on at all times to avoid missing an availability window!  You might want to think about adding a shortcut to it in your startup folder for when Windows patches itself and reboots
3. For best results, have alert messages sent to you as text messages (for instance, if you have Verizon, you can specify [Mobile #]@vtext.com as the address to send alerts to.  If you choose to use regular Email, make sure your client is checking for new messages as frequently as possible.  Availability windows close very quickly!

Setup:
1. Extract SNESHunter.exe and SNESHunter.exe.config to any desired location (just keep them in the same directory!)
2. Double-click SNESHunter.exe.  The first time you run it, you will be prompted to enter information about the Email account you want to use to send alerts.  You only have to do this once.  An Email configuration file will be created.  Don't lose it!
3. The console window will report on availability status for each monitored merchant.

Advanced Users:
- Open SNESHunter.exe.config in a text editor for some additional configurations you can customize
- You have the ability to add your own merchants to SNESHunter.exe.config.  The syntax is:
  [Merchant Name],[Item URL],[HTML search pattern]
  The HTML search pattern needs to be properly escaped as it is contained in an XML file.  
  You want to trigger an alert when the HTML GET response sent from the Merchant website indicates availability.
  A good way to figure out what that would look like is to look at the raw HTML for a product that is in-stock & ensure that this pattern does NOT currently appear on the SNES Classic page for that merchant (assuming it's out of stock, of course)

Send any questions and report bugs to: SNES.Hunter.Help@gmail.com